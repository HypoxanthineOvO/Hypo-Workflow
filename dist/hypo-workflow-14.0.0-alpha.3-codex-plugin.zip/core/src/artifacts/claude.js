import { mkdir, readFile, rm, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import { renderClaudeStatusMonitorManifest } from "../claude-status/index.js";
import { planClaudeCodexDelegation } from "../claude-codex/index.js";
import { commandMap } from "../commands/index.js";
import { buildModelPoolClaudeAgents, loadConfig } from "../config/index.js";
import {
  ASK_QUESTIONS_GUIDANCE,
  CONSULTATION_FIRST_ACTION_BOUNDARY_GUIDANCE,
  FOUR_RULE_DISCIPLINE_GUIDANCE,
  renderDeepSeekToolCallingRules,
} from "./agent-guidance.js";

const HW_VERSION = "14.0.0-alpha.3";

export async function writeClaudeCodePluginArtifacts(outDir = ".", options = {}) {
  void outDir;
  void options;
  throw deferredAdapterError("Claude Code");
}

async function writeClaudeCodeSlashCommandArtifacts(outDir, commands, options = {}) {
  const written = [];
  for (const command of commands) {
    const relative = claudeSlashCommandRelativePath(command);
    if (!relative) continue;
    const absolute = join(outDir, relative);
    await mkdir(dirname(absolute), { recursive: true });
    await writeFile(absolute, renderClaudeCodeSlashCommand(command, options), "utf8");
    written.push(relative);
  }
  return written;
}

function claudeSlashCommandRelativePath(command) {
  const canonical = String(command.canonical || "");
  if (!canonical.startsWith("/hw:")) return null;
  const commandName = canonical.slice("/hw:".length).trim();
  if (!commandName) return null;
  const parts = commandName.split(/[:\s]+/).filter(Boolean);
  if (parts.length === 0) return null;
  return join("commands", ...parts.slice(0, -1), `${parts.at(-1)}.md`);
}

export function renderClaudeCodeSlashCommand(command = {}, options = {}) {
  const routeGuidance = claudeCommandSpecificGuidance(command);
  const deepSeekRules = renderDeepSeekToolCallingRules(options.model || options.mainModel || "deepseek-v4-pro", "Claude Code");
  return [
    "---",
    `description: Hypo-Workflow mapping for ${command.canonical}`,
    "hypo_workflow_managed: true",
    "---",
    "",
    `# ${command.canonical}`,
    "",
    `Canonical command: \`${command.canonical}\``,
    `Route: \`${command.route}\``,
    `Skill: \`${command.skill}\``,
    "",
    `Load the corresponding Hypo-Workflow skill instructions from \`${command.skill}\`, then execute \`${command.canonical}\` semantics with any user-provided arguments.`,
    "",
    CONSULTATION_FIRST_ACTION_BOUNDARY_GUIDANCE,
    "",
    routeGuidance.trimEnd(),
    "",
    FOUR_RULE_DISCIPLINE_GUIDANCE,
    "",
    ASK_QUESTIONS_GUIDANCE,
    "",
    deepSeekRules,
    "",
    "Before acting, inspect the relevant context when present:",
    "",
    "- `.pipeline/config.yaml`",
    "- `.pipeline/cycle.yaml`",
    "- `.pipeline/state.yaml`",
    "- `.pipeline/rules.yaml`",
    "- current prompt/report files for pipeline commands",
    "- open patches for Patch commands",
    "",
    "Keep this command as a Claude Code plugin slash-command mapping, not a separate runner. Claude Code performs the work; Hypo-Workflow files remain the source of truth.",
    "",
  ].filter((line) => line !== undefined && line !== null).join("\n");
}

function claudeCommandSpecificGuidance(command) {
  if (command.canonical === "/hw:plan") {
    return "If the user provides `--deep`, route to `/hw:plan:deep` as an alias before ordinary planning. Ordinary `/hw:plan` keeps the Discover, Technical Stack, Architecture, Decompose, and Generate gates; Deep Plan context or conversion output must not skip them. Confirmation is handled by in-phase Question Tool / Ask gates.";
  }
  if (command.canonical === "/hw:plan:deep") {
    return "This is also the target for the `/hw:plan --deep` alias. It creates or updates a durable discussion package before ordinary `/hw:plan`. It must not skip ordinary named Plan phase gates after `convert`.";
  }
  if (command.canonical === "/hw:plan:technical-stack") {
    return "Run the Technical Stack phase after Discover has produced visible requirements. Discuss implementation substrate, existing stack, integration mechanisms, constraints, and validation tooling; then show the phase artifact and use a Question Tool / Ask gate before Architecture.";
  }
  if (command.canonical === "/hw:plan:architecture") {
    return "Run the Architecture phase after Technical Stack is confirmed. Read the current architecture baseline, produce architecture diagrams and integration points, show the phase artifact, and use a Question Tool / Ask gate before Decompose.";
  }
  if (command.canonical === "/hw:patch fix") {
    return "Patch Fix lane: read the Patch first, preserve distinct `test`, `implement`, and `audit` worker identities for code/test changes, and do not close the Patch until worker lifecycle evidence is recorded.";
  }
  if (command.canonical === "/hw:pr create") {
    return "Change Request lane: exclude `.pipeline/` runtime artifacts by default, ask before remote writes, and keep PR payloads separate from workflow state unless the user explicitly requests a workflow-state migration.";
  }
  return "";
}

async function removeLegacyClaudeAliasSkills(outDir) {
  const removed = [];
  for (const command of commandMap("claude-code")) {
    const alias = legacyClaudeAliasName(command);
    const skillDir = join(outDir, "skills", alias);
    const skillFile = join(skillDir, "SKILL.md");
    const existing = await readOptionalText(skillFile);
    if (!existing || !/Thin Claude Code alias/i.test(existing)) continue;
    await rm(skillDir, { recursive: true, force: true });
    removed.push(`skills/${alias}`);
  }
  return removed;
}

function legacyClaudeAliasName(command) {
  return String(command.canonical || "")
    .replace(/^\//, "")
    .replace(/[:\s]+/g, "-");
}

const CLAUDE_AGENT_ROLES = Object.freeze([
  "plan",
  "code",
  "test",
  "review",
  "debug",
  "docs",
  "report",
  "compact",
]);

export async function writeClaudeCodeAgentArtifacts(outDir = ".", options = {}) {
  void outDir;
  void options;
  throw deferredAdapterError("Claude Code agent");
}

export function buildClaudeAgentRoutingMetadata(config = {}) {
  const agents = buildModelPoolClaudeAgents(config);
  const codexPluginConfig = config.claude_code?.codex_plugin || {};
  const codexConfigured = codexPluginConfig.enabled === true;
  const codexCapability = normalizeCodexPluginCapability(codexPluginConfig);
  return {
    source: "model_pool+claude_code",
    routing: "declaration-first",
    codex_plugin: {
      configured: codexConfigured,
      profile: codexPluginConfig.profile || "balanced",
      capability_status: codexCapability.status,
      capability_source: codexCapability.source,
      capability_detection: [
        "installed",
        "missing",
        "command_unavailable",
        "unsupported_version",
      ],
      delegation: planClaudeCodexDelegation({
        profile: codexPluginConfig.profile || "balanced",
        configured: codexConfigured,
        capability: codexCapability,
      }),
    },
    dynamic_selection: {
      task_category: {
        documentation: "docs",
        implementation: "code",
        testing: "test",
        review: "review",
        debug: "debug",
        report: "report",
        compact: "compact",
      },
      test_profile: {
        webapp: "test",
        "agent-service": "test",
        research: "docs",
      },
      failure_state: {
        test_failure: "debug",
        runtime_error: "debug",
        docs_gap: "docs",
      },
    },
    agents,
  };
}

function normalizeCodexPluginCapability(config = {}) {
  if (config.capability && typeof config.capability === "object") {
    return {
      ...config.capability,
      status: config.capability.status || "missing",
      source: config.capability.source || "provided",
    };
  }
  if (config.capability_status) {
    return {
      status: config.capability_status,
      source: "configured_status",
    };
  }
  return {
    status: "missing",
    source: "not_detected",
  };
}

export function renderClaudeCodeAgent(role, agent = {}) {
  const name = `hw-${role}`;
  const model = agent.model || "default";
  const deepSeekRules = renderDeepSeekToolCallingRules(model, "Claude Code");
  return `---\nname: ${name}\ndescription: Hypo-Workflow Claude Code ${role} subagent.\nmodel: ${model}\nhypo_workflow_managed: true\n---\n\n# ${name}\n\nRole: \`${role}\`\nModel: \`${model}\`\n\nUse this Claude Code subagent for Hypo-Workflow ${role} work. The model is generated from the shared \`model_pool.roles\` contract, refined by \`claude_code.agents.${role}.model\` when explicitly configured.\n\n${CONSULTATION_FIRST_ACTION_BOUNDARY_GUIDANCE}\n\n${FOUR_RULE_DISCIPLINE_GUIDANCE}\n\n${ASK_QUESTIONS_GUIDANCE}\n\n${deepSeekRules ? `${deepSeekRules}\n\n` : ""}Do not call models directly from Hypo-Workflow core. Claude Code remains responsible for actual model invocation; this file only declares routing intent.\n`;
}

export function selectClaudeAgentRole(context = {}) {
  const failure = String(context.failure_state || "").toLowerCase();
  if (Number(context.retry_count || 0) > 0 && ["test_failure", "runtime_error", "failed"].includes(failure)) {
    return { role: "debug", reason: "retry/failure state favors debug" };
  }

  const profile = String(context.test_profile || "").toLowerCase();
  if (["webapp", "agent-service"].includes(profile)) return { role: "test", reason: `${profile} test profile requires validation` };
  if (profile === "research") return { role: "docs", reason: "research profile favors docs/evidence" };

  const category = String(context.task_category || context.category || "").toLowerCase();
  if (/doc|guide|readme/.test(category)) return { role: "docs", reason: "documentation task" };
  if (/test|qa|validation/.test(category)) return { role: "test", reason: "test task" };
  if (/review|audit/.test(category)) return { role: "review", reason: "review task" };
  if (/debug|bug|failure/.test(category)) return { role: "debug", reason: "debug task" };
  if (/report|release/.test(category) || /report|release/i.test(context.milestone_name || "")) return { role: "report", reason: "report task" };
  if (/compact|context/.test(category)) return { role: "compact", reason: "compact task" };
  if (/implement|code|build/.test(category)) return { role: "code", reason: "implementation task" };
  return { role: "plan", reason: "default planning role" };
}

async function readOptionalText(path) {
  try {
    return await readFile(path, "utf8");
  } catch (error) {
    if (error.code === "ENOENT") return "";
    throw error;
  }
}

function isManagedClaudeAgent(source) {
  return /^hypo_workflow_managed:\s*true$/m.test(source);
}

export function renderClaudeCodePluginManifest(options = {}) {
  return {
    name: "hw",
    version: options.version || HW_VERSION,
    description: "Hypo-Workflow for Claude Code. The plugin namespace is intentionally `hw`; plugin-root commands map /hw:* to existing workflow Skills.",
    author: {
      name: "Hypoxanthine",
      url: "https://github.com/HypoxanthineOvO",
    },
    homepage: "https://github.com/HypoxanthineOvO/Hypo-Workflow",
    license: "MIT",
    keywords: [
      "hypo-workflow",
      "workflow",
      "planning",
      "tdd",
      "prompt-engineering",
      "ai-agent",
      "status",
      "claude-code",
      "codex",
      "opencode",
    ],
    skills: "./skills/",
    monitors: "./monitors/monitors.json",
  };
}

export function renderClaudeCodeMarketplaceManifest(options = {}) {
  return {
    name: "hypoxanthine-hypo-workflow",
    owner: {
      name: "Hypoxanthine",
    },
    metadata: {
      description: "Official Hypo-Workflow marketplace for Claude Code installation.",
    },
    plugins: [
      {
        name: "hw",
        source: "./",
        version: options.version || HW_VERSION,
      description: "Hypo-Workflow Claude Code plugin. Uses the `hw` namespace so plugin-root commands expose /hw:* backed by existing Skills.",
        author: {
          name: "Hypoxanthine",
          url: "https://github.com/HypoxanthineOvO",
        },
        license: "MIT",
        homepage: "https://github.com/HypoxanthineOvO/Hypo-Workflow",
        tags: [
          "hypo-workflow",
          "claude-code",
          "workflow",
          "planning",
          "tdd",
          "release",
        ],
      },
    ],
  };
}

function deferredAdapterError(platform) {
  const error = new Error(`${platform} adapter generation is deferred; this writer is retired and performed no writes.`);
  error.code = "ERR_HYPO_WORKFLOW_ADAPTER_DEFERRED";
  error.status = "deferred";
  error.writes = [];
  return error;
}
