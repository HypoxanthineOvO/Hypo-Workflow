---
name: accept
description: Accept the active Goal or Cycle at its final pending acceptance gate. Use for /hw:accept or an explicit user acceptance statement.
---

# Accept Delivery

## 输出语言规则

用户可见内容遵循项目输出语言；缺失时跟随当前对话语言。内部 schema key 保持英文。

Require the active Delivery to be `pending_acceptance`. Build the exact `delivery.accept` Receipt context from current Runtime, issue the user-scoped Receipt through the host decision gate, then call `store.accept`.

Import Core from the installed bundle, pass the target workspace as `root`, and create Delivery/Receipt stores with the same explicit zero-argument Clock. Show the complete Receipt binding first; only after explicit user confirmation issue it, then call `accept` with a unique safe mutation `{ id }`.

Reject stale plan, state, scope, actor, object, or reused Receipt bindings. Acceptance changes only final Delivery state to `accepted`; Cycle Milestones remain verified and have no individual acceptance state.

Explain the delivered result, verification evidence, remaining risks, and acceptance effect directly in chat.
